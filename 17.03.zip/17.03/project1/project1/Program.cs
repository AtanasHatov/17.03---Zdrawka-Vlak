﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

namespace project1
{
    public class Program
    { 
        public static void Main(string[] args)
        {

        }
    }

}

